echo "this is script 1 in `pwd`";
