describe('Battery (navigator.battery)', function () {;
    it("should exist", function() {
        expect(navigator.battery).toBeDefined();
    });
});
