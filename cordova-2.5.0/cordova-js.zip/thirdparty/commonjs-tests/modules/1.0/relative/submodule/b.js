exports.foo = function () {
};
