Project Template
===

This project template needs to be built to be installed.


This template includes the full source code for Windows Phone 7


In order to build this template in Visual Studio Express for Windows Phone 7 :

1. Open the solution file in Visual Studio
2. Choose File->Export Template and follow the directions.