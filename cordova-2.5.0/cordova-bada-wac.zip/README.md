Cordova for Bada WAC
====================

Supports: Acceleration, Geolocation, Connection, Device, Compass, Capture, Camera, Events (deviceready)

Build steps
===========
1. clone repository
2. import into IDE as Bada Flash / C++ application
3. HTML/CSS/JavaScript live in the Res folder
4. Run on Target device or Emulator
5. Done!
